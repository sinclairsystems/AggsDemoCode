Older beta version of game running on the Gallary.html page
Using the gamelogic.js for functionality