//Word guessing game Beta 

//storing all html hint image sets in variables
const hint1 = document.getElementById("hint1")
const hint2 = document.getElementById("hint2")
const hint3 = document.getElementById("hint3")
const hint4 = document.getElementById("hint4")
const hint5 = document.getElementById("hint5")
const hint6 = document.getElementById("hint6")
//storing html hint text in variables		
const hint1Txt = document.getElementById("hint1Txt")
const hint2Txt = document.getElementById("hint2Txt")
const hint3Txt = document.getElementById("hint3Txt")
const hint4Txt = document.getElementById("hint4Txt")
const hint5Txt = document.getElementById("hint5Txt")
const hint6Txt = document.getElementById("hint6Txt")


const guessTable = document.getElementById("guessTable");
const hintArray = [[hint1,hint1Txt],[hint2,hint2Txt],[hint3,hint3Txt],[hint4,hint4Txt],[hint5,hint5Txt],[hint6,hint6Txt]]
const hintTxtArray = ["it acient","it wooden","used by warriors"," its a wepon"," its handheld","taiaha"]	

const hangManInput = document.getElementById("hangManInput")
const hangmanSubmit = document.getElementById("hangmanSubmit")
const hangmanResult = document.getElementById("hangmanResult")
const wordToGuess = "taiaha"
const allowedGuesses = 5

let guessedWords = []
let matchedLettersArray = []
let numberOfGuesses = 0


//disables controls and reveals all remaining images once game is ended
function endGame(){
	
	hangmanSubmit.classList.remove("submitButton")
	hangmanSubmit.innerText = "Game Over"
	hangmanSubmit.disabled = true;
	
	for(let i = numberOfGuesses-1; i <= allowedGuesses; i++){
		changeImage(hintArray[i],hintTxtArray[i])
	}
}

//conditional statement to evaluate users guess once its validated
function makeGuess(wordGuessed){
	let matchingLettersForWord = checkLetters(wordGuessed,wordToGuess)	
	numberOfGuesses++ //shorthand of numberOfGuesses = numberOfGuesses + 1	
	if(wordGuessed == wordToGuess){
		alert("you win")
		//disable submit button
		endGame()
	}else if(wordGuessed != wordToGuess && numberOfGuesses <= allowedGuesses){
		//guess incorrect
		alert("word incorrect try again")
		changeImage(hintArray[numberOfGuesses-1],hintTxtArray[numberOfGuesses-1])
		
	}else{
		//game over
		endGame()
		alert("you have lost the word was: "+wordToGuess)		
	}

	guessedWords.push(wordGuessed)
	matchedLettersArray.push(matchingLettersForWord)	
	mapArraysToTable(guessedWords,matchedLettersArray)
}	

//takes a hint reference and hint text from hint array and changes CSS classes to swap images
function changeImage(hint,hintTxt){
	let topImg = hint[0].getElementsByTagName( 'img' )[1]
	topImg.classList.add("transparent")
	hint[1].innerText = hintTxt;	
}

//takes guessed word and target word and returns the letters that match
function checkLetters (guessedWord,targetWord){
	let matchingLetters = ""
	for(let i=0; i<guessedWord.length;i++){
		if(targetWord.includes(guessedWord.charAt(i))){			
			matchingLetters += guessedWord.charAt(i)
			targetWord = targetWord.replace(guessedWord.charAt(i),"")

		}
	}
	
	return matchingLetters	
}
//function to mange the creation and appending previous guesses
function createGuessTableRow(firstCol,secondCol){
	let tr = null
	let guessedTd = null
	let matchingTd = null
	let guessedWord = ""
	let matchingLetters = ""
	
	guessedWord = document.createTextNode(firstCol)
	matchingLetters = document.createTextNode(secondCol)				
	guessedTd = document.createElement('td')
	matchingTd = document.createElement('td')
	tr = document.createElement('tr')
	
	guessedTd.appendChild(guessedWord)
	matchingTd.appendChild(matchingLetters)
	tr.appendChild(guessedTd)
	tr.appendChild(matchingTd)
	guessTable.appendChild(tr)	
	
}

//due to being fool of a took table must be reset and redrawn after each guess (most probably a much better way)
function resetGuessTable(){
	guessTable.innerHTML = ""
	createGuessTableRow("previous guesses","letters that matched")

}

//these dont need to be passed in as params as they are globally accessable	u moron
function mapArraysToTable(guessedWordArray,matchingLetterysArray){
	resetGuessTable();
	
	for (let i=0;i<guessedWordArray.length;i++){
		createGuessTableRow(guessedWordArray[i],matchingLetterysArray[i])			

	}		
}

//checks if user input is blank
function checkIfBlank(inputString){
		let isBlank = false
		if(inputString == ""){
			isBlank = true
		}
		return isBlank
}

//checks if user input contains any illegal characters
function ContainsIllegalChars(inputString){
	let containsIllegal = false
	specialCharacters = "*|,\":<>[]{}`\';()@&$#%!?";
	for(let i = 0;i < inputString.length;i++){
		if(!isNaN(Number(inputString[i]))){
			containsIllegal = true
		}else if(specialCharacters.indexOf(inputString[i]) != -1){
			containsIllegal = true
		}
	}	
	return containsIllegal
}


//Entry point method
function validateInput(){
	let inputString = (hangManInput.value.toLowerCase()).trim();
	let isBlank = checkIfBlank(inputString)
	let containsIllegal = ContainsIllegalChars(inputString) //left off finishing this

	if(containsIllegal){
		alert("Guess contains illegal characters")		
	}else if(isBlank){
		alert("guess is blank")
	}else{
		//call makeGuess once input is valid
		makeGuess(inputString)
	}
	
}

hangmanSubmit.onclick = validateInput
	
	
		

	
	
	