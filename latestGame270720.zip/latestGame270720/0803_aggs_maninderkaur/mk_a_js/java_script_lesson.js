/*const firstNumInput = document.getElementById("addFirstNumInput");
const addSecondNumInput = document.getElementById("addSecondNumInput");
const addButton = document.getElementById("addButton");

const subFirstNumInput = document.getElementById("subFirstNumInput");
const subSecondNumInput = document.getElementById("subSecondNumInput");
const subButton = document.getElementById("subButton");

const multiplyFirstNumInput = document.getElementById("multiplyFirstNumInput");
const multiplySecondNumInput = document.getElementById("multiplySecondNumInput");
const multiplyButton = document.getElementById("multiplyButton");

const divideFirstNumInput = document.getElementById("divideFirstNumInput");
const divideSecondNumInput = document.getElementById("divideSecondNumInput");
const divideButton = document.getElementById("divideButton");


function addNumbers(){
	const firstNumber = Number(addSecondNumInput.value);
	const secondNumber = Number(addSecondNumInput.value);
	const result = firstNumber + secondNumber;
	alert(result)
	
}

function subtractNumbers(){
	const firstNumber = Number(subFirstNumInput.value);
	const secondNumber = Number(subSecondNumInput.value);
	const result = firstNumber - secondNumber;
	alert(result)
	
}

function multiplyNumbers(){
	const firstNumber = Number(multiplyFirstNumInput.value);
	const secondNumber = Number(multiplySecondNumInput.value);
	const result = firstNumber * secondNumber;
	alert(result)
	
}

function divideNumbers(){
	const firstNumber = Number(divideFirstNumInput.value);
	const secondNumber = Number(divideSecondNumInput.value);
	const result = firstNumber / secondNumber;
	alert(result)
	
}

addButton.onclick = addNumbers; 
subButton.onclick = subtractNumbers;
multiplyButton.onclick = multiplyNumbers;
divideButton.onclick = divideNumbers;

/*let myAge = 15;

if(myAge < 12){
	alert("you can watch PG rated movies only");
}else if(myAge < 16){
	alert("you can watch m rated movies and pg rated movies");
}else{
	alert("you can watch whatever you like");
}*/






const userAgeInput = document.getElementById("userAgeInput");
const submitButton = document.getElementById("submitButton");



function ageUserBy5(userAge){
	return userAge + "5";
}

function submitButtonClicked(){
	const userAge = Number(userAgeInput.value);
	alert("Thanks you for submitting your age of "+userAge+ ", we will now age you by 5 years");
	
	const newUserAge = ageUserBy5(userAge);
	
	alert("you are now:" + newUserAge + "years old");

}

submitButton.onclick = submitButtonClicked; 

















































